document.observe("xwiki:dom:loaded", function(){
  var tableCounter = 0;
  var tableIdPrefix = "macro_sortable_tables_";

  var findSortHeader = function(table) {
    var thCell = table.descendants().filter(function(e){return e.nodeName.toUpperCase()=='TH'}).first();
    if (thCell) {
      var tr = thCell.parentNode;
      tr.addClassName('sortHeader');
    }
  }

  $$("#xwikicontent table").each(function(table) {
    tableCounter++;
    if (macro_sortabletables_sortable) {
      tableCounter++;
      table.addClassName('grid')
      table.addClassName('sortable')
      table.addClassName('doOddEven');
      if (table.getAttribute('id')==null) {
        table.setAttribute('id', tableIdPrefix + tableCounter);
      }
      findSortHeader(table);
      // we do not need to call this, as we are (hopefully) before window.load
      //ts_makeSortable(table);
    }
    if (macro_sortabletables_filterable) {
      table.addClassName('grid')
      table.addClassName('filterable');
      if (!macro_sortabletables_sortable) { // else already done
        if (table.getAttribute('id')==null) {
          table.setAttribute('id', tableIdPrefix + tableCounter);
        }
        findSortHeader(table);
      }
      // setFilterGrid(table.getAttribute('id'), (getHeaderRow(table)) );
    }
  })
});
